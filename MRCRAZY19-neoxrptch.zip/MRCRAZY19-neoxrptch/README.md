## neoxr-bot
WhatsApp Bot (Base)

### Database Setup

Create a heroku account, then go to the AddOns page and add Heroku Postgres.

### Installation

```
$ git clone https://github.com/neoxr/neoxr-bot
```

And then go into the folder and type this on your console.
```
$ npm i
$ node . <session_name>
```

<p align="center"><img src="https://profile-counter.glitch.me/{neoxr}/count.svg" alt="neoxr :: Visitor's Count" /></p>

## License
Copyright (c) 2022 Neoxr . Licensed under the [GNU GPLv3](https://github.com/neoxr/neoxr-bot/blob/master/LICENSE)
